<?php 
/**
 * electrothemecategoriessidebar.php
 * 
 * Language file for a front page.
 */
$_['heading_title']     = 'Electro Theme - Categories Sidebar';
$_['text_categories']   = 'Categories';
$_['text_price']        = 'Price';
$_['text_brand']        = 'Brands';
$_['text_top_selling']  = 'Top Sellings';