<?php 
/**
 * electrothemecategoriessidebar.php
 * 
 * Language file for a front page.
 */
$_['heading_title']     = 'Electro Theme - Categories Sidebar';
$_['text_categories']   = 'Категории';
$_['text_price']        = 'Цена';
$_['text_brand']        = 'Производители';
$_['text_top_selling']  = 'Самые продаваемые';